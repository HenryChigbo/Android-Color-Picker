package com.inducesmile.colorpickers;

public interface OnColorSelectChangeListener {

    void onColorChange(int color);
}
